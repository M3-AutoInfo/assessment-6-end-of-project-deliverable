<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Box Hill Clinic - Login </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="./main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body class="bg-gray-100 ">

    <!-- end header -->
    <main class="min-h-[70vh] flex justify-center items-center">
       <!-- component -->
       <aside class="ml-[-100%]  z-10 top-0 pb-3 px-6 w-full flex flex-col justify-between h-screen border-r bg-white transition duration-300 md:w-4/12 lg:ml-0 lg:w-[25%] xl:w-[20%] 2xl:w-[15%]">
        <div>
            <div class="mt-8 text-center">
              <div class="mt-8 text-center">
                <div class="text-2xl  text-blue-600 font-bold pb-5">
                    Box Hill Clinic
                </div>
                <img src="../../fontend/images/doctors/austin-distel-7bMdiIqz_J4-unsplash.jpg" alt="" class="w-10 h-10 m-auto rounded-full object-cover lg:w-28 lg:h-28">
                <h5 class="hidden mt-4 text-xl font-semibold text-gray-600 lg:block">Dr.Suman</h5>
                <span class="hidden text-gray-400 lg:block">Doctor</span>
            </div>
    
             
    
            <ul class="space-y-2 tracking-wide mt-8">
                <li>
                    <a href="../index.html" aria-label="dashboard" class="relative px-4 py-3 flex items-center space-x-4 rounded-xl text-whit">
                       <i class="fas fa-tachometer-alt"></i>
                        <span class="-mr-1 font-medium">Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="../appointments/" class="px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <i class="fas fa-calendar-alt"></i>
                        <span class="group-hover:text-gray-700">Appointments</span>
                    </a>
                </li>
                <li>
                  <a href="../patients/" class="px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                      <i class="fas fa-user"></i>
                      <span class="group-hover:text-gray-700">Patients</span>
                  </a>
              </li> 
                <li>
                    <a href="../reports/" class="px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <i class="fas fa-user-injured"></i>
                        <span class="group-hover:text-gray-700">Reports</span>
                    </a>
                </li>
                <li>
                    <a href="../settings/" class="px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                        <i class="fas fa-cog"></i>
                        <span class="group-hover:text-gray-700">Setting</span>
                    </a>
                </li>
        
            </ul>
        </div>
    
        <div class="px-6 -mx-6 pt-4 flex justify-between items-center border-t">
            <button class="px-4 py-3 flex items-center space-x-4 rounded-md text-gray-600 group">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                <span class="group-hover:text-gray-700">Logout</span>
            </button>
        </div>
        </div>
    </aside>
<div class="ml-auto mb-6 lg:w-[75%] xl:w-[80%] 2xl:w-[85%]">
    <div class=" h-16 border-b bg-white lg:py-2.5 ">
        <div class="px-6 flex items-center justify-between space-x-4 2xl:container">
            <h5 hidden class="text-lg text-gray-600 font-medium lg:block">Dashboard</h5>
            <button class="w-12 h-16 -mr-2 border-r lg:hidden">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 my-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
            <div class="flex space-x-4 ">
                <!--search bar -->
                <div hidden class="md:block">
                    <div class="relative flex items-center text-gray-400 focus-within:text-cyan-400">
                        <span class="absolute left-4 h-6 flex items-center pr-3 border-r border-gray-300">
                        <svg xmlns="http://ww50w3.org/2000/svg" class="w-4 fill-current" viewBox="0 0 35.997 36.004">
                            <path id="Icon_awesome-search" data-name="search" d="M35.508,31.127l-7.01-7.01a1.686,1.686,0,0,0-1.2-.492H26.156a14.618,14.618,0,1,0-2.531,2.531V27.3a1.686,1.686,0,0,0,.492,1.2l7.01,7.01a1.681,1.681,0,0,0,2.384,0l1.99-1.99a1.7,1.7,0,0,0,.007-2.391Zm-20.883-7.5a9,9,0,1,1,9-9A8.995,8.995,0,0,1,14.625,23.625Z"></path>
                        </svg>
                        </span>
                        <input type="search" name="leadingIcon" id="leadingIcon" placeholder="Search here" class="w-full pl-14 pr-4 py-2.5 rounded-xl text-sm text-gray-600 outline-none border border-gray-300 focus:border-cyan-300 transition">
                    </div>
                </div>
                <!--/search bar -->
                <button aria-label="search" class="w-10 h-10 rounded-xl border bg-gray-100 focus:bg-gray-100 active:bg-gray-200 md:hidden">
                    <svg xmlns="http://ww50w3.org/2000/svg" class="w-4 mx-auto fill-current text-gray-600" viewBox="0 0 35.997 36.004">
                        <path id="Icon_awesome-search" data-name="search" d="M35.508,31.127l-7.01-7.01a1.686,1.686,0,0,0-1.2-.492H26.156a14.618,14.618,0,1,0-2.531,2.531V27.3a1.686,1.686,0,0,0,.492,1.2l7.01,7.01a1.681,1.681,0,0,0,2.384,0l1.99-1.99a1.7,1.7,0,0,0,.007-2.391Zm-20.883-7.5a9,9,0,1,1,9-9A8.995,8.995,0,0,1,14.625,23.625Z"></path>
                    </svg>
                </button>
                <button aria-label="notification" class="w-10 h-10 rounded-xl border bg-gray-100 focus:bg-gray-100 active:bg-gray-200">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 m-auto text-gray-600" viewBox="0 0 20 20" fill="currentColor">
                        <path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z" />
                    </svg>
                </button>
            </div>
        </div>
    </div>
    <div class="px-6 pt-6 2xl:container min-h-[89vh]">
      <div class=" p-[1rem] m-[1rem]  overflow-x-scroll h-[80vh]"> 
        <div class="flex justify-center mt-10">
            <form action="" class="max-w-[30rem] shadow p-[1rem] bg-white">
                <div class="text-xl pb-[1rem]">
                    Profile
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div class="col-span-2">
                        <label for="profile" class="text-sm">Profile</label>
                        <input type="file" name="profile" id="profile" class="w-full border border-gray-300 p-2 rounded-md">
                    </div> 
                    <div class="col-span-2">
                        <label for="name" class="text-sm">Display Name</label>
                        <input type="text" name="name" id="name" value="Doctor 1" class="w-full border border-gray-300 p-2 rounded-md">
                    </div>
                    <div class="mb-4 col-span-2">
                        <label for="email" class="block mb-2">Email</label>
                        <input type="email" name="email" id="email" value="user@gmail.com" class="w-full border-2 border-gray-200 p-2 rounded-md focus:outline-none focus:border-blue-800" placeholder="Enter your email">
                    </div>
                    <div class="mb-4">
                        <label for="password" class="block mb-2">Password</label>
                        <input type="password" name="password" id="password" class="w-full border-2 border-gray-200 p-2 rounded-md focus:outline-none focus:border-blue-800" placeholder="Enter your password">
                    </div>
                    <div class="mb-4">
                        <label for="confirm_password" class="block mb-2">Confirm Password</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="w-full border-2 border-gray-200 p-2 rounded-md focus:outline-none focus:border-blue-800" placeholder="Confirm your password">
                    </div>
                </div>
                    <div class="py-4 flex justify-end">
                        <a href="#" class="bg-blue-800 text-white p-2 rounded-md text-xs  hover:bg-gray-500">Save</a>
                    </div>
                </form>
           </div>
      </div>
    </div>
</div>
    </main>
    <!-- footer -->


    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js" integrity="sha512-fD9DI5bZwQxOi7MhYWnnNPlvXdp/2Pj3XSTRrFs5FQa4mizyGLnJcN6tuvUS6LbmgN1ut+XGSABKvjN0H6Aoow==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>