<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Box Hill Clinic - Login </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="./main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body class="bg-gray-100 ">
  <!-- header -->
  <div class=" bg-white shadow-sm">
    <header class="container mx-auto flex justify-between py-4 px-10">
        <a href="./index.html" class="cursor-pointer text-2xl  text-blue-600 font-bold">
            Box Hill Clinic
        </a>
        <div class="hidden lg:block">   
            <a href="./index.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Home</a>
            <a href="./doctors.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Doctors</a>
            <a href="./about.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">About Us</a>
            <a href="./login.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Login</a>/
            <a href="./register.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Register</a>
        </div>
    </header>
</div>
<!-- end header -->
    <main class="min-h-[70vh] flex justify-center items-center">
        <div class="bg-white p-[2rem] rounded-md  shadow-md">
            <div class="text-2xl font-semibold text-center mb-4">Reset Password</div>
            <div>
                <form action="" method="post">
                    <div class="mb-4">
                        <label for="email" class="block mb-2">Email</label>
                        <input type="email" name="email" id="email" class="w-full border-2 border-gray-200 p-2 rounded-md focus:outline-none focus:border-blue-800" placeholder="Enter your email">
                    </div>
                    <div class="mb-4">
                        <button type="submit" class="w-full bg-blue-800 text-white p-2 rounded-md hover:bg-blue-900">Reset</button>
                    </div>
                 
                </form>
            </div>
        </div>
    </main>
    <!-- footer -->
    <div class="bg-gray-50 py-10 text-center mt-[5rem]">
        <div class="max-w-[80vw] mx-auto grid-cols-1 lg:grid grid-cols-3">
            <div>
                <div class="text-2xl font-semibold  p-2">About Us</div>
                <div class="text-sm  p-2">
                    Box Hill Family Clinic is a GPA plus accredited general practice which has been providing comprehensive health care to all families and individuals of all ages at the clinic since 2008. The project is based on creating a management system that will deal with the problems existing in the current system. 
              </div>
            </div>

            <div>
                <div class="text-2xl font-semibold  p-2">Actions</div>
                <div class="text-sm  p-2">
                    <ul>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Book Appointment</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">View Doctors</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">View Clinics</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">View Patients</li>
                    </ul>
                </div>
            </div>
            <div>
                <div class="text-2xl font-semibold  p-2">Contact Us</div>
                <div class="text-sm  p-2">
                    <ul>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Facebook</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Twitter</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Instagram</li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <div class="bg-blue-50 flex justify-between ">
        <div>
            <div class="p-4">
                © Copyright <b> 
                    <a href="#" class="text-blue-800">
                        Box Hill Clinic
                    </a>
                </b> All Rights Reserved.
            </div>
        </div>
        <div class="flex gap-1">
            <div class="px-2 py-4">
                <a href="#" class="text-blue-800">
                    <i class="fab fa-facebook-f"></i>
                </a>
            </div>
            <div class="px-2 py-4">
                <a href="#" class="text-blue-800">
                    <i class="fab fa-twitter"></i>
                </a>
            </div>
            <div class="px-2 py-4">
                <a href="#" class="text-blue-800">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js" integrity="sha512-fD9DI5bZwQxOi7MhYWnnNPlvXdp/2Pj3XSTRrFs5FQa4mizyGLnJcN6tuvUS6LbmgN1ut+XGSABKvjN0H6Aoow==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>