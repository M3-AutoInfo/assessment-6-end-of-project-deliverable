<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Box Hill Clinic </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="./main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body class="bg-gray-100 ">
    <!-- header -->
    <div class=" bg-white shadow-sm">
        <header class="container mx-auto flex justify-between py-4 px-10">
            <a href="./index.html" class="cursor-pointer text-2xl  text-blue-600 font-bold">
                Box Hill Clinic
            </a>
            <div class="hidden lg:block">   
                <a href="./index.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Home</a>
                <a href="./doctors.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Doctors</a>
                <a href="./about.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">About Us</a>
                <a href="./login.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Login</a>/
                <a href="./register.html" class="p-2 hover:border-1 hover:border-b-2 border-blue-800 ease-in-out duration-100">Register</a>
            </div>
        </header>
    </div>
    <!-- end header -->

    <!-- doctors -->
    <div class="py-10 max-w-[80vw] mx-auto grid grid-cols-1 lg:grid-cols-3">
        <div class=" p-4 flex justify-center mx-auto ">
            <img src="./images/doctors/austin-distel-7bMdiIqz_J4-unsplash.jpg" alt="" class="w-full object-cover h-[20rem] rounded-md object-cover">
        </div>
        <div class="p-[1rem] bg-white mx-4 rounded-lg w-full col-span-2">
            <div class="text-2xl font-semibold p-2">
                Dr. Syad 
                <span  class="text-sm p-2 text-gray-700">
                (CEO/ Founder)
            </span>
            </div>
            <div class="text-sm p-2 text-gray-700 " >
                A doctor is a highly trained and skilled medical professional who diagnoses, treats, and prevents illnesses, injuries, 
                and various medical conditions in individuals. Doctors play a crucial role in healthcare systems worldwide, utilizing their
                 extensive medical knowledge and expertise to provide comprehensive medical care to patients.
            </div>
           <div class="flex justify-center mt-10">
            <form action="" class="max-w-[30rem] shadow p-[1rem]">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div class="col-span-2">
                        <label for="name" class="text-sm">Name</label>
                        <input type="text" name="name" id="name" class="w-full border border-gray-300 p-2 rounded-md">
                    </div>
                    <div>
                        <label for="email" class="text-sm">Email</label>
                        <input type="email" name="email" id="email" class="w-full border border-gray-300 p-2 rounded-md">
                    </div>
                    <div>
                        <label for="phone" class="text-sm">Phone</label>
                        <input type="text" name="phone" id="phone" class="w-full border border-gray-300 p-2 rounded-md">
                    </div>
                    <div>
                        <label for="date" class="text-sm">Date</label>
                        <input type="date" name="date" id="date" class="w-full border border-gray-300 p-2 rounded-md">
                    </div>
                    <div>
                        <label for="time" class="text-sm">Time</label>
                        <input type="time" name="time" id="time" class="w-full border border-gray-300 p-2 rounded-md">
                    </div>
                    <div class="col-span-2">
                        <label for="doctor" class="text-sm">Doctor</label>
                        <select name="doctor" id="doctor" class="w-full border border-gray-300 p-2 rounded-md">
                            <option value="">Select Doctor</option>
                            <option value="" selected>
                                Dr. Suman
                            </option>
                            <option value="">
                                Dr. Suman
                            </option>
                        </select>
                    </div>
                    <div  class="col-span-2">
                        <label for="message" class="text-sm">Message</label>
                        <textarea name="message" id="message" cols="30" rows="5" class="w-full border border-gray-300 p-2 rounded-md"></textarea>
                    </div>
                    </div>
                    <div class="py-4 flex justify-end">
                        <a href="#" class="bg-blue-800 text-white p-2 rounded-md text-xs  hover:bg-gray-500">Book Appointment</a>
                    </div>
                </form>
           </div>
        </div>
     
    </div>
    <!-- end doctor -->

    <!-- footer -->
    <div class="bg-gray-50 py-10 text-center mt-[5rem]">
        <div class="max-w-[80vw] mx-auto grid-cols-1 lg:grid grid-cols-3">
            <div>
                <div class="text-2xl font-semibold  p-2">About Us</div>
                <div class="text-sm  p-2">
                    Box Hill Family Clinic is a GPA plus accredited general practice which has been providing comprehensive health care to all families and individuals of all ages at the clinic since 2008. The project is based on creating a management system that will deal with the problems existing in the current system. 
              </div>
            </div>

            <div>
                <div class="text-2xl font-semibold  p-2">Actions</div>
                <div class="text-sm  p-2">
                    <ul>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Book Appointment</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">View Doctors</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">View Clinics</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">View Patients</li>
                    </ul>
                </div>
            </div>
            <div>
                <div class="text-2xl font-semibold  p-2">Contact Us</div>
                <div class="text-sm  p-2">
                    <ul>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Facebook</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Twitter</li>
                        <li class="cursor-pointer hover:bg-white hover:text-blue-800 px-2">Instagram</li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <div class="bg-blue-50 flex justify-between ">
        <div>
            <div class="p-4">
                © Copyright <b> 
                    <a href="#" class="text-blue-800">
                        Box Hill Clinic
                    </a>
                </b> All Rights Reserved.
            </div>
        </div>
        <div class="flex gap-1">
            <div class="px-2 py-4">
                <a href="#" class="text-blue-800">
                    <i class="fab fa-facebook-f"></i>
                </a>
            </div>
            <div class="px-2 py-4">
                <a href="#" class="text-blue-800">
                    <i class="fab fa-twitter"></i>
                </a>
            </div>
            <div class="px-2 py-4">
                <a href="#" class="text-blue-800">
                    <i class="fab fa-instagram"></i>
                </a>
            </div>
        </div>
    </div>
    <!-- footer end -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js" integrity="sha512-fD9DI5bZwQxOi7MhYWnnNPlvXdp/2Pj3XSTRrFs5FQa4mizyGLnJcN6tuvUS6LbmgN1ut+XGSABKvjN0H6Aoow==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
</body>
</html>